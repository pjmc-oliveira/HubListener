#!/usr/bin/python
# Test each director for LaTeX files and attempt to compile them

import os
import shutil
import subprocess
import sys

from Queue import Queue


ROOT_DIR = os.path.abspath(os.getcwd())


def main():
    exceptions_file_path = sys.argv[1]  # First command line argument
    artifacts_file_path = None
    if len(sys.argv) > 2:
        artifacts_file_path = sys.argv[2] 
        artifacts_file_path = os.path.join(ROOT_DIR, artifacts_file_path)
        if not os.path.exists(artifacts_file_path):
            os.makedirs(artifacts_file_path)
    to_skip = get_exceptions(exceptions_file_path)
    to_compile = get_latex_files(to_skip)
    failed = compile_latex(to_compile, artifacts_path=artifacts_file_path)

    if failed:
        print 'The following LaTeX files failed to compile:'
        for failure in failed:
            print failure
        sys.exit(1)
    else:
        print 'Success!'


# Collect the list of LaTeX files we should skip over
def get_exceptions(exceptions_file_path):
    to_skip = []
    with open(exceptions_file_path, 'r') as exceptions_file:
        for exception in exceptions_file:
            if exception.startswith('#'):
                continue
            to_skip.append(os.path.join(ROOT_DIR, exception.strip()))
    return to_skip


# Collect the list of LaTeX files in the repository
# Not including any files list in the to_skip parameter
def get_latex_files(to_skip=[]):
    to_check = Queue()
    to_check.put(ROOT_DIR)
    to_compile = []
    # Breadth-First Search for all LaTeX files
    while not to_check.empty():
        directory = to_check.get()
        for item in os.listdir(directory):
            full_path = os.path.join(directory, item)
            if item.startswith('.'):
                # skip hidden folders
                continue
            if to_skip and full_path in to_skip:
                # skip anything in the to_skip list
                continue

            if os.path.isdir(full_path):
                # if this is a directory, check its contents
                to_check.put(full_path)
            elif item.endswith('.tex'):
                # if it is a tex file, add it to the list to compile
                to_compile.append(full_path)
    return to_compile


# Attempt to compile every LaTeX file in the to_compile parameter
def compile_latex(to_compile, artifacts_path=None):
    failed = []
    for full_file_path in to_compile:
        tex_file = os.path.basename(full_file_path)
        location = os.path.dirname(full_file_path)
        os.chdir(location)
        try:
            # Compile LaTeX
            subprocess.check_output(['pdflatex', '-halt-on-error',
                '-interaction=nonstopmode', tex_file])
            # Copy all artifacts to a common location
            if artifacts_path is not None:
                # The line below creates a unique name based on original path
                # ex. ROOT_DIR/Labs/L01/L01.tex turns into Labs_L01_L01.pdf
                formatted_name = full_file_path[len(ROOT_DIR)+1:-4]
                formatted_name = formatted_name.replace(os.sep, '_')
                formatted_name = os.path.join(artifacts_path, formatted_name)
                formatted_name = formatted_name + '.pdf'
                # Copy to the new location with the new name
                shutil.copy(full_file_path, formatted_name)
        except subprocess.CalledProcessError as e:
            print full_file_path[len(ROOT_DIR):] + ' failed to compile. Output was:\n'
            print e.output
            failed.append(full_file_path[len(ROOT_DIR):])
        os.chdir(ROOT_DIR)
    return failed


if __name__ == '__main__':
    main()