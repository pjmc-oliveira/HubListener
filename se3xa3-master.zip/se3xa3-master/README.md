# Welcome to the course git for Software Engineering 3XA3 - 2016 Edition

### This course is being led by Spencer Smith (@smiths).

#### TAs for the course include:

Dan Szymczak (@szymczdm)

Mojdeh Sayari-Nejad (@sayarinm)

Mustafa Haddara (@haddarma) 

Christopher McDonald (@mcdonacb)
