# Module Interface Specification #

Suggest following something like the example used in Lab 11 (Box 3D).

Use doxygen (or equivalent) to document the interface for your modules.
