#!/usr/bin/python
# Count the commits per author in a git repository
import os
import subprocess
import sys

def getLog(path=None):
    if path is not None:
        current_dir = os.getcwd()
        os.chdir(path)
    out = subprocess.check_output(["git", "log", "--format='%aN <%aE>'",
        "--shortstat"])
    lines = out.split('\n')

    if path is not None:
        os.chdir(current_dir)
    return lines

def countCommits(log):
    commits = {}
    additions = {}
    deletions = {}
    total = 0
    current_author = ''

    for line in log:
        if line.strip() == '':
            continue

        if line.startswith(' '):
            # commit stats
            total += 1
            stats = line.split(',')
            a = d = 0
            if len(stats) > 1:
                a = stats[1].strip().split()[0]
                if len(stats) > 2:
                    d = stats[2].strip().split()[0]

            # increment the number of commits here
            # not when we first find the author name
            # because gitlab doesn't count merge commits as real commits
            # and the git log output won't include these stats for merge
            # commits
            # so we wait to find these stats before incrementing the
            # number of commits per author
            commits[current_author] += 1
            additions[current_author] += int(a)
            deletions[current_author] += int(d)
        else:
            # got author name
            current_author = line
            if current_author not in commits:
                commits[current_author] = 0
                additions[current_author] = 0
                deletions[current_author] = 0

    return commits, total, additions, deletions

def printCommits(commits, additions, deletions):
    for authorName in commits:
        numCommits = commits[authorName]
        numAdditions = additions[authorName]
        numDeletions = deletions[authorName]
        if authorName.startswith('\''):
            authorName = authorName[1:]
        if authorName.endswith('\''):
            authorName = authorName[:-1]

        msg = "%s: %s commits (%s additions and %s deletions)"
        print msg % (authorName, numCommits, numAdditions, numDeletions)

def printUsage():
    print "Usage: ./git_counter.py [dir]"
    print "Optionally pass in a filepath to count all commits in git repo"
    print "  located at that directory."
    print "If no directory given, counts all commits in the current directory."

def main():
    if len(sys.argv) > 1:
        if sys.argv[1] in ['-h', '--help']:
            printUsage()
            sys.exit()
        else:
            log = getLog(sys.argv[1])
    else:
        log = getLog()

    commits, total, additions, deletions = countCommits(log)

    print "Total commits: %d" % total
    printCommits(commits, additions, deletions)

if __name__ == '__main__':
    main()
